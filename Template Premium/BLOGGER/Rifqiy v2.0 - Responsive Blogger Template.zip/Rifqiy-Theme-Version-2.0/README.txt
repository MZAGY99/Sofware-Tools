Version 2.0 Have New Script Code
Please Read Documentation File to see How To Install it



Version 2.0
Recode All Script
Added:
- Shortcode [youtube,dailymotion,maps,soundcloud,image,tab,accordion, etc..]
- Post Pagination
- Lock Content
- Featured Post Content
- Custom Title and Sub Title support in Post
- Ads below title, Ads Inside Post, Ads end Post
- Related Post Style (Carousel,Simple,and First Big)
- Recommended Widget
- Complex Widget
- Social Counter
- Featured Post (4 Style)
- 10+ Widget by Label Style
- and More..

Fixed:
- Post Schema.org Format
- Improve SEO


Version: 1.3
Fixed/Change:
- Summary Script (Added youtube playicon)
- Recent Post by Tag Script (Added youtube playicon)
- Related Post Script (Added youtube playicon)
- Page navigation script (Added youtube playicon)

Added:
- Support Mega Menu
- Lightweight version (inside lightweight folder)
- New meta tag (Support Facebook, Twitter, Google+)

										
Version 1.2
- Fixed : Some CSS Bug.
- Added: Auto Resize Image

Version 1.1:
Fixed:
- Recent Post by Tag Script.
- Summary Script.
- Related Post Script.
- NewsTicker Script.
- JSON Search Script.

Added:
- 4 New Recent Post by Tag Style.
- Recent Post by Tag Support Shortcode
- Post Application (Print,Email,Text Find)